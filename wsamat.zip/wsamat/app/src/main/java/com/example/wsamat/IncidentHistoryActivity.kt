package com.example.wsamat

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.wsamat.adapter.IncidentAdapter
import com.example.wsamat.data.DatabaseHelper

class IncidentHistoryActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var adapter: IncidentAdapter
    private lateinit var rvIncidents: RecyclerView
    private lateinit var tvEmpty: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_incident_history)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Incident History"

        dbHelper = DatabaseHelper(this)

        rvIncidents = findViewById(R.id.rvIncidents)
        tvEmpty = findViewById(R.id.tvEmptyHistory)

        rvIncidents.layoutManager = LinearLayoutManager(this)
        adapter = IncidentAdapter(
            incidents = emptyList(),
            onMapClick = { incident -> openMapUrl(incident.mapUrl) }
        )
        rvIncidents.adapter = adapter

        findViewById<Button>(R.id.btnClearHistory).setOnClickListener {
            showClearConfirmDialog()
        }

        loadHistory()
    }

    private fun loadHistory() {
        val incidents = dbHelper.getAllIncidents()
        adapter.updateData(incidents)

        if (incidents.isEmpty()) {
            tvEmpty.visibility = View.VISIBLE
            rvIncidents.visibility = View.GONE
        } else {
            tvEmpty.visibility = View.GONE
            rvIncidents.visibility = View.VISIBLE
        }
    }

    private fun openMapUrl(mapUrl: String) {
        if (mapUrl.isEmpty()) return
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(mapUrl))
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Unable to open map link.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showClearConfirmDialog() {
        AlertDialog.Builder(this)
            .setTitle("Clear History")
            .setMessage("Are you sure you want to clear all recorded incident logs?")
            .setPositiveButton("Clear All") { _, _ ->
                dbHelper.clearIncidents()
                Toast.makeText(this, "Incident log cleared", Toast.LENGTH_SHORT).show()
                loadHistory()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
