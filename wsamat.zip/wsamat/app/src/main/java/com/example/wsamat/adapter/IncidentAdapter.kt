package com.example.wsamat.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.wsamat.R
import com.example.wsamat.data.Incident
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class IncidentAdapter(
    private var incidents: List<Incident>,
    private val onMapClick: (Incident) -> Unit
) : RecyclerView.Adapter<IncidentAdapter.IncidentViewHolder>() {

    class IncidentViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvType: TextView = itemView.findViewById(R.id.tvIncidentType)
        val tvStatus: TextView = itemView.findViewById(R.id.tvIncidentStatus)
        val tvTime: TextView = itemView.findViewById(R.id.tvIncidentTimestamp)
        val tvLocation: TextView = itemView.findViewById(R.id.tvIncidentLocation)
        val btnMap: Button = itemView.findViewById(R.id.btnViewMap)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): IncidentViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_incident, parent, false)
        return IncidentViewHolder(view)
    }

    override fun onBindViewHolder(holder: IncidentViewHolder, position: Int) {
        val incident = incidents[position]
        holder.tvType.text = incident.eventType
        holder.tvStatus.text = incident.status.uppercase(Locale.getDefault())

        val dateFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
        holder.tvTime.text = dateFormat.format(Date(incident.timestamp))

        holder.tvLocation.text = incident.locationText

        if (incident.mapUrl.isNotEmpty()) {
            holder.btnMap.visibility = View.VISIBLE
            holder.btnMap.setOnClickListener { onMapClick(incident) }
        } else {
            holder.btnMap.visibility = View.GONE
        }
    }

    override fun getItemCount(): Int = incidents.size

    fun updateData(newIncidents: List<Incident>) {
        this.incidents = newIncidents
        notifyDataSetChanged()
    }
}
