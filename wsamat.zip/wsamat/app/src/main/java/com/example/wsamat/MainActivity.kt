package com.example.wsamat

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.wsamat.data.DatabaseHelper
import com.example.wsamat.data.UserPreferences
import com.google.android.material.card.MaterialCardView

class MainActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var userPrefs: UserPreferences

    private lateinit var tvHeaderGreeting: TextView
    private lateinit var tvProtectionBadge: TextView
    private lateinit var tvStatusContactsCount: TextView
    private lateinit var tvStatusShake: TextView
    private lateinit var tvStatusCheckIn: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dbHelper = DatabaseHelper(this)
        userPrefs = UserPreferences(this)

        tvHeaderGreeting = findViewById(R.id.tvHeaderGreeting)
        tvProtectionBadge = findViewById(R.id.tvProtectionBadge)
        tvStatusContactsCount = findViewById(R.id.tvStatusContactsCount)
        tvStatusShake = findViewById(R.id.tvStatusShake)
        tvStatusCheckIn = findViewById(R.id.tvStatusCheckIn)

        // 1-Tap Emergency SOS Button
        findViewById<Button>(R.id.btnMainSos).setOnClickListener {
            val intent = Intent(this, SosCountdownActivity::class.java).apply {
                putExtra("TRIGGER_SOURCE", "1-Tap SOS Button")
            }
            startActivity(intent)
        }

        // Navigation Cards
        findViewById<MaterialCardView>(R.id.cardTrustedContacts).setOnClickListener {
            startActivity(Intent(this, TrustedContactsActivity::class.java))
        }

        findViewById<MaterialCardView>(R.id.cardEmergencyResources).setOnClickListener {
            startActivity(Intent(this, EmergencyResourcesActivity::class.java))
        }

        findViewById<MaterialCardView>(R.id.cardSafetyCheckIn).setOnClickListener {
            startActivity(Intent(this, SafetyCheckInActivity::class.java))
        }

        findViewById<MaterialCardView>(R.id.cardFakeCall).setOnClickListener {
            startActivity(Intent(this, FakeCallActivity::class.java))
        }

        findViewById<MaterialCardView>(R.id.cardIncidentHistory).setOnClickListener {
            startActivity(Intent(this, IncidentHistoryActivity::class.java))
        }

        findViewById<MaterialCardView>(R.id.cardProfileSetup).setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        updateDashboardStatus()
    }

    private fun updateDashboardStatus() {
        val userName = userPrefs.userName
        tvHeaderGreeting.text = "Hello, $userName!"

        val contactCount = dbHelper.getContactCount()
        tvStatusContactsCount.text = contactCount.toString()

        val isShakeActive = userPrefs.isShakeEnabled
        tvStatusShake.text = if (isShakeActive) "ON" else "OFF"
        tvStatusShake.setTextColor(
            if (isShakeActive) ContextCompat.getColor(this, android.R.color.holo_green_dark)
            else ContextCompat.getColor(this, android.R.color.darker_gray)
        )

        val isCheckInActive = userPrefs.isSafetyCheckInActive
        tvStatusCheckIn.text = if (isCheckInActive) "ON" else "OFF"
        tvStatusCheckIn.setTextColor(
            if (isCheckInActive) ContextCompat.getColor(this, android.R.color.holo_green_dark)
            else ContextCompat.getColor(this, android.R.color.darker_gray)
        )

        val hasLocationPermission = ContextCompat.checkSelfPermission(
            this, android.Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        val hasSmsPermission = ContextCompat.checkSelfPermission(
            this, android.Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED

        if (hasLocationPermission && hasSmsPermission && contactCount > 0) {
            tvProtectionBadge.text = "PROTECTED"
            tvProtectionBadge.setBackgroundColor(ContextCompat.getColor(this, android.R.color.holo_green_dark))
        } else {
            tvProtectionBadge.text = "SETUP NEEDED"
            tvProtectionBadge.setBackgroundColor(ContextCompat.getColor(this, android.R.color.holo_orange_dark))
        }
    }
}
