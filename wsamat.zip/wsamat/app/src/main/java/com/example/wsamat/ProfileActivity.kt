package com.example.wsamat

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.wsamat.data.UserPreferences
import com.google.android.material.textfield.TextInputEditText

class ProfileActivity : AppCompatActivity() {

    private lateinit var userPrefs: UserPreferences
    private lateinit var etName: TextInputEditText
    private lateinit var etPhone: TextInputEditText
    private lateinit var etEmergencyNote: TextInputEditText

    private lateinit var tvLocationStatus: TextView
    private lateinit var tvSmsStatus: TextView
    private lateinit var tvContactsStatus: TextView
    private lateinit var tvNotificationStatus: TextView

    private lateinit var btnGrantLocation: Button
    private lateinit var btnGrantSms: Button
    private lateinit var btnGrantContacts: Button
    private lateinit var btnGrantNotification: Button

    private val requestLocationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { updatePermissionStatuses() }

    private val requestSmsPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { updatePermissionStatuses() }

    private val requestContactsPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { updatePermissionStatuses() }

    private val requestNotificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { updatePermissionStatuses() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "User Profile & Setup"

        userPrefs = UserPreferences(this)

        etName = findViewById(R.id.etName)
        etPhone = findViewById(R.id.etPhone)
        etEmergencyNote = findViewById(R.id.etEmergencyNote)

        tvLocationStatus = findViewById(R.id.tvLocationStatus)
        tvSmsStatus = findViewById(R.id.tvSmsStatus)
        tvContactsStatus = findViewById(R.id.tvContactsStatus)
        tvNotificationStatus = findViewById(R.id.tvNotificationStatus)

        btnGrantLocation = findViewById(R.id.btnGrantLocation)
        btnGrantSms = findViewById(R.id.btnGrantSms)
        btnGrantContacts = findViewById(R.id.btnGrantContacts)
        btnGrantNotification = findViewById(R.id.btnGrantNotification)

        loadProfileData()
        setupListeners()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatuses()
    }

    private fun loadProfileData() {
        etName.setText(userPrefs.userName)
        etPhone.setText(userPrefs.userPhone)
        etEmergencyNote.setText(userPrefs.emergencyNote)
    }

    private fun setupListeners() {
        findViewById<Button>(R.id.btnSaveProfile).setOnClickListener {
            userPrefs.userName = etName.text.toString().trim()
            userPrefs.userPhone = etPhone.text.toString().trim()
            userPrefs.emergencyNote = etEmergencyNote.text.toString().trim()
            Toast.makeText(this, "Profile updated successfully!", Toast.LENGTH_SHORT).show()
        }

        btnGrantLocation.setOnClickListener {
            requestLocationPermissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }

        btnGrantSms.setOnClickListener {
            requestSmsPermissionLauncher.launch(Manifest.permission.SEND_SMS)
        }

        btnGrantContacts.setOnClickListener {
            requestContactsPermissionLauncher.launch(Manifest.permission.READ_CONTACTS)
        }

        btnGrantNotification.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                requestNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                Toast.makeText(this, "Notification permission granted automatically on this Android version.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun updatePermissionStatuses() {
        // Location
        val hasLocation = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        tvLocationStatus.text = if (hasLocation) "Status: Granted ✓" else "Status: Denied ✗"
        btnGrantLocation.isEnabled = !hasLocation

        // SMS
        val hasSms = ContextCompat.checkSelfPermission(
            this, Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED
        tvSmsStatus.text = if (hasSms) "Status: Granted ✓" else "Status: Denied ✗"
        btnGrantSms.isEnabled = !hasSms

        // Contacts
        val hasContacts = ContextCompat.checkSelfPermission(
            this, Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED
        tvContactsStatus.text = if (hasContacts) "Status: Granted ✓" else "Status: Denied ✗"
        btnGrantContacts.isEnabled = !hasContacts

        // Notification
        val hasNotification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
        tvNotificationStatus.text = if (hasNotification) "Status: Granted ✓" else "Status: Denied ✗"
        btnGrantNotification.isEnabled = !hasNotification
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
