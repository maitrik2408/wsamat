package com.example.wsamat.data

import android.content.Context
import android.content.SharedPreferences

class UserPreferences(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    var userName: String
        get() = prefs.getString(KEY_USER_NAME, "User") ?: "User"
        set(value) = prefs.edit().putString(KEY_USER_NAME, value).apply()

    var userPhone: String
        get() = prefs.getString(KEY_USER_PHONE, "") ?: ""
        set(value) = prefs.edit().putString(KEY_USER_PHONE, value).apply()

    var emergencyNote: String
        get() = prefs.getString(
            KEY_EMERGENCY_NOTE,
            "EMERGENCY! I need urgent help. Please check my current live location:"
        ) ?: "EMERGENCY! I need urgent help. Please check my current live location:"
        set(value) = prefs.edit().putString(KEY_EMERGENCY_NOTE, value).apply()

    var isShakeEnabled: Boolean
        get() = prefs.getBoolean(KEY_SHAKE_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_SHAKE_ENABLED, value).apply()

    var fakeCallerName: String
        get() = prefs.getString(KEY_FAKE_CALLER_NAME, "Mom") ?: "Mom"
        set(value) = prefs.edit().putString(KEY_FAKE_CALLER_NAME, value).apply()

    var fakeCallerNumber: String
        get() = prefs.getString(KEY_FAKE_CALLER_NUMBER, "+1 555-0199") ?: "+1 555-0199"
        set(value) = prefs.edit().putString(KEY_FAKE_CALLER_NUMBER, value).apply()

    var isSafetyCheckInActive: Boolean
        get() = prefs.getBoolean(KEY_CHECKIN_ACTIVE, false)
        set(value) = prefs.edit().putBoolean(KEY_CHECKIN_ACTIVE, value).apply()

    var checkInTargetTimeMillis: Long
        get() = prefs.getLong(KEY_CHECKIN_TARGET_TIME, 0L)
        set(value) = prefs.edit().putLong(KEY_CHECKIN_TARGET_TIME, value).apply()

    companion object {
        private const val PREF_NAME = "wsamat_user_prefs"
        private const val KEY_USER_NAME = "user_name"
        private const val KEY_USER_PHONE = "user_phone"
        private const val KEY_EMERGENCY_NOTE = "emergency_note"
        private const val KEY_SHAKE_ENABLED = "shake_enabled"
        private const val KEY_FAKE_CALLER_NAME = "fake_caller_name"
        private const val KEY_FAKE_CALLER_NUMBER = "fake_caller_number"
        private const val KEY_CHECKIN_ACTIVE = "checkin_active"
        private const val KEY_CHECKIN_TARGET_TIME = "checkin_target_time"
    }
}
