package com.example.wsamat

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.wsamat.data.DatabaseHelper
import com.example.wsamat.data.Incident
import com.example.wsamat.data.UserPreferences
import com.example.wsamat.utils.LocationHelper
import com.example.wsamat.utils.SmsHelper

class SosCountdownActivity : AppCompatActivity() {

    private lateinit var tvCountdownText: TextView
    private lateinit var tvTriggerSource: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var layoutCountdownView: LinearLayout
    private lateinit var layoutResultView: LinearLayout
    private lateinit var tvResultLocation: TextView
    private lateinit var tvResultSms: TextView

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var userPrefs: UserPreferences
    private lateinit var locationHelper: LocationHelper
    private lateinit var smsHelper: SmsHelper

    private var countDownTimer: CountDownTimer? = null
    private var vibrator: Vibrator? = null
    private var triggerSource: String = "One-tap SOS"
    private var isCancelled = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sos_countdown)

        triggerSource = intent.getStringExtra("TRIGGER_SOURCE") ?: "One-tap SOS"

        dbHelper = DatabaseHelper(this)
        userPrefs = UserPreferences(this)
        locationHelper = LocationHelper(this)
        smsHelper = SmsHelper(this)

        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator

        tvCountdownText = findViewById(R.id.tvCountdownText)
        tvTriggerSource = findViewById(R.id.tvTriggerSource)
        progressBar = findViewById(R.id.progressBarCountdown)
        layoutCountdownView = findViewById(R.id.layoutCountdownView)
        layoutResultView = findViewById(R.id.layoutResultView)
        tvResultLocation = findViewById(R.id.tvResultLocation)
        tvResultSms = findViewById(R.id.tvResultSms)

        tvTriggerSource.text = "Source: $triggerSource"

        findViewById<Button>(R.id.btnCancelSos).setOnClickListener {
            cancelSos()
        }

        findViewById<Button>(R.id.btnDoneSos).setOnClickListener {
            finish()
        }

        startCountdown()
    }

    private fun startCountdown() {
        vibratePattern()
        countDownTimer = object : CountDownTimer(10000, 100) {
            override fun onTick(millisUntilFinished: Long) {
                val seconds = (millisUntilFinished / 1000) + 1
                tvCountdownText.text = seconds.toString()
                val progress = ((millisUntilFinished.toDouble() / 10000.0) * 100).toInt()
                progressBar.progress = progress
            }

            override fun onFinish() {
                if (!isCancelled) {
                    dispatchEmergencyAlerts()
                }
            }
        }.start()
    }

    private fun cancelSos() {
        isCancelled = true
        countDownTimer?.cancel()
        vibrator?.cancel()
        Toast.makeText(this, "Emergency SOS Cancelled.", Toast.LENGTH_SHORT).show()

        // Log cancellation in database
        dbHelper.addIncident(
            Incident(
                timestamp = System.currentTimeMillis(),
                eventType = triggerSource,
                locationText = "User Cancelled during Countdown",
                mapUrl = "",
                status = "Cancelled"
            )
        )
        finish()
    }

    private fun dispatchEmergencyAlerts() {
        layoutCountdownView.visibility = View.GONE
        layoutResultView.visibility = View.VISIBLE

        tvResultLocation.text = "Acquiring current GPS Location..."
        tvResultSms.text = "Preparing Emergency SMS..."

        val contacts = dbHelper.getAllContacts()

        locationHelper.fetchCurrentLocation { loc ->
            val locationText = loc?.formattedAddress ?: "Location unavailable"
            val mapUrl = loc?.mapUrl ?: ""

            tvResultLocation.text = "Location: $locationText"

            val customNote = userPrefs.emergencyNote
            val isSent = smsHelper.sendEmergencySms(contacts, customNote, mapUrl)

            val statusStr = if (isSent) "Dispatched to ${contacts.size} Contacts" else "Fallback SMS App Opened"
            tvResultSms.text = "Alert Status: $statusStr"

            // Save Incident log
            dbHelper.addIncident(
                Incident(
                    timestamp = System.currentTimeMillis(),
                    eventType = triggerSource,
                    locationText = locationText,
                    mapUrl = mapUrl,
                    status = statusStr
                )
            )
        }
    }

    private fun vibratePattern() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(500)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onDestroy() {
        countDownTimer?.cancel()
        vibrator?.cancel()
        super.onDestroy()
    }
}
