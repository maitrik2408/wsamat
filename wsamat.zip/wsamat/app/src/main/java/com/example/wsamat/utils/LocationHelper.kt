package com.example.wsamat.utils

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationManager
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LocationHelper(private val context: Context) {

    private val fusedLocationClient: FusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(context)

    data class LocationResult(
        val latitude: Double,
        val longitude: Double,
        val accuracy: Float,
        val timestamp: Long,
        val mapUrl: String,
        val formattedAddress: String
    )

    @SuppressLint("MissingPermission")
    fun fetchCurrentLocation(onResult: (LocationResult?) -> Unit) {
        val cancellationTokenSource = CancellationTokenSource()

        try {
            fusedLocationClient.getCurrentLocation(
                Priority.PRIORITY_HIGH_ACCURACY,
                cancellationTokenSource.token
            ).addOnSuccessListener { location: Location? ->
                if (location != null) {
                    onResult(buildLocationResult(location))
                } else {
                    // Fallback to LocationManager last known location
                    fetchFallbackLocation(onResult)
                }
            }.addOnFailureListener {
                fetchFallbackLocation(onResult)
            }
        } catch (e: Exception) {
            fetchFallbackLocation(onResult)
        }
    }

    @SuppressLint("MissingPermission")
    private fun fetchFallbackLocation(onResult: (LocationResult?) -> Unit) {
        try {
            val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            val gpsLocation = locationManager?.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            val networkLocation = locationManager?.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)

            val bestLocation = when {
                gpsLocation != null && networkLocation != null -> {
                    if (gpsLocation.time > networkLocation.time) gpsLocation else networkLocation
                }
                gpsLocation != null -> gpsLocation
                else -> networkLocation
            }

            if (bestLocation != null) {
                onResult(buildLocationResult(bestLocation))
            } else {
                onResult(null)
            }
        } catch (e: Exception) {
            onResult(null)
        }
    }

    private fun buildLocationResult(location: Location): LocationResult {
        val mapUrl = "https://maps.google.com/?q=${location.latitude},${location.longitude}"
        val dateFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
        val formattedTime = dateFormat.format(Date(location.time))
        val addressStr = "Lat: %.5f, Lng: %.5f (Accuracy: %.0fm, Time: %s)"
            .format(location.latitude, location.longitude, location.accuracy, formattedTime)

        return LocationResult(
            latitude = location.latitude,
            longitude = location.longitude,
            accuracy = location.accuracy,
            timestamp = location.time,
            mapUrl = mapUrl,
            formattedAddress = addressStr
        )
    }
}
