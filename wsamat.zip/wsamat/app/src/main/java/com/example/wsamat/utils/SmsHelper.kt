package com.example.wsamat.utils

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.telephony.SmsManager
import android.widget.Toast
import com.example.wsamat.data.Contact

class SmsHelper(private val context: Context) {

    fun sendEmergencySms(
        contacts: List<Contact>,
        customMessage: String,
        mapUrl: String
    ): Boolean {
        if (contacts.isEmpty()) {
            Toast.makeText(context, "No trusted contacts configured!", Toast.LENGTH_SHORT).show()
            return false
        }

        val fullMessage = if (mapUrl.isNotEmpty()) {
            "$customMessage\nLocation: $mapUrl"
        } else {
            customMessage
        }

        var sentCount = 0
        val smsManager: SmsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            context.getSystemService(SmsManager::class.java)
        } else {
            @Suppress("DEPRECATION")
            SmsManager.getDefault()
        }

        for (contact in contacts) {
            val phone = contact.phone.trim()
            if (phone.isNotEmpty()) {
                try {
                    val parts = smsManager.divideMessage(fullMessage)
                    if (parts.size > 1) {
                        smsManager.sendMultipartTextMessage(phone, null, parts, null, null)
                    } else {
                        smsManager.sendTextMessage(phone, null, fullMessage, null, null)
                    }
                    sentCount++
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }

        if (sentCount == 0) {
            // Fallback to launching system SMS app
            launchSmsIntent(contacts, fullMessage)
            return false
        }

        Toast.makeText(context, "Emergency SMS dispatched to $sentCount contacts!", Toast.LENGTH_LONG).show()
        return true
    }

    private fun launchSmsIntent(contacts: List<Contact>, message: String) {
        val phoneNumbers = contacts.joinToString(";") { it.phone.trim() }
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:$phoneNumbers")
            putExtra("sms_body", message)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Unable to launch SMS app.", Toast.LENGTH_SHORT).show()
        }
    }
}
