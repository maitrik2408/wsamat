package com.example.wsamat

import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.view.LayoutInflater
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.wsamat.adapter.ContactAdapter
import com.example.wsamat.data.Contact
import com.example.wsamat.data.DatabaseHelper
import com.google.android.material.button.MaterialButton

class TrustedContactsActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var adapter: ContactAdapter
    private lateinit var rvContacts: RecyclerView
    private lateinit var tvEmpty: TextView

    private val pickContactLauncher = registerForActivityResult(
        ActivityResultContracts.PickContact()
    ) { contactUri: Uri? ->
        contactUri?.let { processPickedContact(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_trusted_contacts)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Trusted Contacts"

        dbHelper = DatabaseHelper(this)

        rvContacts = findViewById(R.id.rvContacts)
        tvEmpty = findViewById(R.id.tvEmptyContacts)

        rvContacts.layoutManager = LinearLayoutManager(this)
        adapter = ContactAdapter(
            contacts = emptyList(),
            onDeleteClick = { contact -> showDeleteConfirmDialog(contact) },
            onItemClick = { contact -> showAddOrEditContactDialog(contact) }
        )
        rvContacts.adapter = adapter

        findViewById<MaterialButton>(R.id.btnAddManual).setOnClickListener {
            showAddOrEditContactDialog(null)
        }

        findViewById<MaterialButton>(R.id.btnPickFromContacts).setOnClickListener {
            pickContactLauncher.launch(null)
        }

        loadContacts()
    }

    private fun loadContacts() {
        val contacts = dbHelper.getAllContacts()
        adapter.updateData(contacts)
        if (contacts.isEmpty()) {
            tvEmpty.visibility = View.VISIBLE
            rvContacts.visibility = View.GONE
        } else {
            tvEmpty.visibility = View.GONE
            rvContacts.visibility = View.VISIBLE
        }
    }

    private fun showAddOrEditContactDialog(existingContact: Contact?) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_contact, null)
        val etName = dialogView.findViewById<EditText>(R.id.etDialogName)
        val etPhone = dialogView.findViewById<EditText>(R.id.etDialogPhone)
        val cbPrimary = dialogView.findViewById<CheckBox>(R.id.cbDialogPrimary)

        if (existingContact != null) {
            etName.setText(existingContact.name)
            etPhone.setText(existingContact.phone)
            cbPrimary.isChecked = existingContact.isPrimary
        }

        val title = if (existingContact == null) "Add Trusted Contact" else "Edit Contact"

        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val name = etName.text.toString().trim()
                val phone = etPhone.text.toString().trim()
                val isPrimary = cbPrimary.isChecked

                if (name.isEmpty() || phone.isEmpty()) {
                    Toast.makeText(this, "Name and Phone cannot be empty", Toast.LENGTH_SHORT).show()
                } else if (!isValidPhoneNumber(phone)) {
                    Toast.makeText(this, "Please enter a valid phone number", Toast.LENGTH_SHORT).show()
                } else {
                    if (existingContact == null) {
                        val contact = Contact(name = name, phone = phone, isPrimary = isPrimary)
                        dbHelper.addContact(contact)
                        Toast.makeText(this, "Contact added!", Toast.LENGTH_SHORT).show()
                    } else {
                        val contact = existingContact.copy(name = name, phone = phone, isPrimary = isPrimary)
                        dbHelper.updateContact(contact)
                        Toast.makeText(this, "Contact updated!", Toast.LENGTH_SHORT).show()
                    }
                    loadContacts()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showDeleteConfirmDialog(contact: Contact) {
        AlertDialog.Builder(this)
            .setTitle("Remove Contact")
            .setMessage("Remove ${contact.name} from trusted emergency contacts?")
            .setPositiveButton("Remove") { _, _ ->
                dbHelper.deleteContact(contact.id)
                Toast.makeText(this, "Contact removed", Toast.LENGTH_SHORT).show()
                loadContacts()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun processPickedContact(uri: Uri) {
        try {
            val cursor = contentResolver.query(uri, null, null, null, null)
            cursor?.use { c ->
                if (c.moveToFirst()) {
                    val idIdx = c.getColumnIndex(ContactsContract.Contacts._ID)
                    val nameIdx = c.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME)
                    val hasPhoneIdx = c.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER)

                    val contactId = if (idIdx >= 0) c.getString(idIdx) else ""
                    val name = if (nameIdx >= 0) c.getString(nameIdx) else "Contact"
                    val hasPhone = if (hasPhoneIdx >= 0) c.getInt(hasPhoneIdx) else 0

                    if (hasPhone > 0) {
                        val phoneCursor = contentResolver.query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                            null,
                            "${ContactsContract.CommonDataKinds.Phone.CONTACT_ID} = ?",
                            arrayOf(contactId),
                            null
                        )
                        phoneCursor?.use { pc ->
                            if (pc.moveToFirst()) {
                                val pIdx = pc.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                                val phone = if (pIdx >= 0) pc.getString(pIdx) else ""
                                if (phone.isNotEmpty()) {
                                    val contact = Contact(name = name, phone = phone)
                                    dbHelper.addContact(contact)
                                    Toast.makeText(this, "Added $name ($phone)", Toast.LENGTH_SHORT).show()
                                    loadContacts()
                                }
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to read picked contact.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun isValidPhoneNumber(phone: String): Boolean {
        val cleanPhone = phone.replace(Regex("[^0-9+]"), "")
        return cleanPhone.length >= 4
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
